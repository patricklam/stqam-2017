/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.entity.Hanging entities that hang}.
 */
package org.bukkit.event.hanging;

