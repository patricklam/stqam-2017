/**
 * {@link org.bukkit.event.Event Events} relating to when a {@link
 * org.bukkit.block.Block block} is changed or interacts with the {@link
 * org.bukkit.World world}.
 */
package org.bukkit.event.block;

