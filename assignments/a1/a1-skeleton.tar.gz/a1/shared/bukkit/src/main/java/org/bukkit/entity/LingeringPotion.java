package org.bukkit.entity;

/**
 * Represents a thrown lingering potion bottle
 */
public interface LingeringPotion extends ThrownPotion { }
