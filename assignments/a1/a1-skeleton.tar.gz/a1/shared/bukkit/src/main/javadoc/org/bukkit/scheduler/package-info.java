/**
 * Classes dedicated to letting {@link org.bukkit.plugin.Plugin plugins} run
 * code at specific time intervals, including thread safety.
 */
package org.bukkit.scheduler;

