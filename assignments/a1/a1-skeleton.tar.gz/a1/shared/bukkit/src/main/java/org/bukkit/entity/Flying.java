package org.bukkit.entity;

/**
 * Represents a Flying Entity.
 */
public interface Flying extends LivingEntity {}
