/**
 * {@link org.bukkit.event.Event Events} relating to programmatic state
 * changes on the server.
 */
package org.bukkit.event.server;

