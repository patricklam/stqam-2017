/**
 * Classes dedicated to providing binary state properties to players.
 */
package org.bukkit.permissions;

