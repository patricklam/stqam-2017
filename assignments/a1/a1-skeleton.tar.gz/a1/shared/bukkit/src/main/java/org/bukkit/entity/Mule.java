package org.bukkit.entity;

/**
 * Represents a Mule - variant of {@link ChestedHorse}.
 */
public interface Mule extends ChestedHorse { }
