/**
 * Classes dedicated to being able to perform serialization specialized for
 * the Bukkit {@link org.bukkit.configuration.Configuration configuration}
 * implementation.
 */
package org.bukkit.configuration.serialization;

