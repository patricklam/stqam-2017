/**
 * Classes dedicated to facilitating deterministic noise.
 */
package org.bukkit.util.noise;

