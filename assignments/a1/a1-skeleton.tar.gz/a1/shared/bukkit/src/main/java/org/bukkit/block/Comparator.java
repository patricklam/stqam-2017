package org.bukkit.block;

/**
 * Represents an on / off comparator.
 */
public interface Comparator extends BlockState { }
