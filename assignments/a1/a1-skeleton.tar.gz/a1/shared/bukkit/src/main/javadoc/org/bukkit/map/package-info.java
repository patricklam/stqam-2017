/**
 * Classes to facilitate plugin handling of {@link org.bukkit.Material#MAP
 * map} displays.
 */
package org.bukkit.map;

