package org.bukkit.entity;

/**
 * Represents a Husk - variant of {@link Zombie}.
 */
public interface Husk extends Zombie { }
