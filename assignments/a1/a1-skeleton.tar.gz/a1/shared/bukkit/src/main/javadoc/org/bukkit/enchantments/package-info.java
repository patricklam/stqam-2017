/**
 * Classes relating to the specialized enhancements to {@link
 * org.bukkit.inventory.ItemStack item stacks}, as part of the {@link
 * org.bukkit.inventory.meta.ItemMeta meta data}.
 */
package org.bukkit.enchantments;

