/**
 * {@link org.bukkit.event.Event Events} relating to weather.
 */
package org.bukkit.event.weather;

