package org.bukkit.entity;

/**
 * Represents a ZombieHorse - variant of {@link AbstractHorse}.
 */
public interface ZombieHorse extends AbstractHorse { }
