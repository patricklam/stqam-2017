/**
 * Classes used to manipulate the voxels in a {@link org.bukkit.World world},
 * including special states.
 */
package org.bukkit.block;

