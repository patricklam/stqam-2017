package org.bukkit.entity;

public interface DragonFireball extends Fireball {}
