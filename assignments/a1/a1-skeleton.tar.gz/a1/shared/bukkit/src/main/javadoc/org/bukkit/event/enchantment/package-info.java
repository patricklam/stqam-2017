/**
 * {@link org.bukkit.event.Event Events} triggered from an {@link
 * org.bukkit.inventory.EnchantingInventory enchantment table}.
 */
package org.bukkit.event.enchantment;

