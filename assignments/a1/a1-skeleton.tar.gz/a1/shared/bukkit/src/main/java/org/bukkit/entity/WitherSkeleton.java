package org.bukkit.entity;

/**
 * Represents a WitherSkeleton - variant of {@link Skeleton}.
 */
public interface WitherSkeleton extends Skeleton { }
