/**
 * Interfaces used to manage the client side score display system.
 */
package org.bukkit.scoreboard;

