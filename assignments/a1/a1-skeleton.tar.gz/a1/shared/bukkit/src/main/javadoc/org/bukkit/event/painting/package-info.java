/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.entity.Painting paintings}, but deprecated for more general
 * {@link org.bukkit.event.hanging hanging} events.
 */
package org.bukkit.event.painting;

