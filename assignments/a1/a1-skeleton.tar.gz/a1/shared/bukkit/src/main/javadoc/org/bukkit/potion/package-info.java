/**
 * Classes to represent various {@link org.bukkit.Material#POTION potion}
 * properties and manipulation.
 */
package org.bukkit.potion;

