/**
 * Classes dedicated to handling triggered code executions.
 */
package org.bukkit.event;

