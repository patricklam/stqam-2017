/**
 * {@link org.bukkit.event.Event Events} triggered by various {@link
 * org.bukkit.World world} states or changes.
 */
package org.bukkit.event.world;

