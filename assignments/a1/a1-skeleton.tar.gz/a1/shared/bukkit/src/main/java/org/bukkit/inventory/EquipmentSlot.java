package org.bukkit.inventory;

public enum EquipmentSlot {

    HAND,
    OFF_HAND,
    FEET,
    LEGS,
    CHEST,
    HEAD
}
