/**
 * Classes for handling {@link org.bukkit.plugin.Plugin plugins} written in
 * java.
 */
package org.bukkit.plugin.java;

