/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.entity.Player players}.
 */
package org.bukkit.event.player;

