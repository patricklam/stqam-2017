/**
 * Interfaces for non-voxel objects that can exist in a {@link
 * org.bukkit.World world}, including all players, monsters, projectiles, etc.
 */
package org.bukkit.entity;

