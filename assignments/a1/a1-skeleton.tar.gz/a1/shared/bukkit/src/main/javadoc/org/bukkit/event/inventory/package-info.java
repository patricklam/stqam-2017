/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.inventory.Inventory inventory} manipulation.
 */
package org.bukkit.event.inventory;

