package org.bukkit.entity;

/**
 * Represents a fishing hook.
 * @deprecated in favor of {@link FishHook}
 */
public interface Fish extends FishHook {
}
