/**
 * {@link org.bukkit.event.Event Events} relating to {@link
 * org.bukkit.entity.Vehicle vehicular entities}.
 */
package org.bukkit.event.vehicle;

