/**
 * More generalized classes in the API.
 */
package org.bukkit;

