/**
 * The interfaces used when manipulating extra data can can be stored inside
 * {@link org.bukkit.inventory.ItemStack item stacks}.
 */
package org.bukkit.inventory.meta;

