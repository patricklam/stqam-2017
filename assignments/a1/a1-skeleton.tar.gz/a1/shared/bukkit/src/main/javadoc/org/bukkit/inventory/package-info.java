/**
 * Classes involved in manipulating player inventories and item interactions.
 */
package org.bukkit.inventory;

