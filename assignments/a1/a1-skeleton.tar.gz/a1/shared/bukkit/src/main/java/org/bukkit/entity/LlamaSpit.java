package org.bukkit.entity;

/**
 * Represents Llama spit.
 */
public interface LlamaSpit extends Projectile { }
