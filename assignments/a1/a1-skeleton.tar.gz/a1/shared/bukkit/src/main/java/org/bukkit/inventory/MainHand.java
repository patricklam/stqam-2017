package org.bukkit.inventory;

/**
 * Represents the chosen main hand of a player
 */
public enum MainHand {
    LEFT,
    RIGHT
}
