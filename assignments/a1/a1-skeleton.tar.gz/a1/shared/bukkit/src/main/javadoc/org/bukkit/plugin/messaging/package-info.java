/**
 * Classes dedicated to specialized plugin to client protocols.
 */
package org.bukkit.plugin.messaging;

