#!/usr/bin/env bash
case $(id -u) in
    0)
        # install latest java (java 8)
        # automatically accept license
        echo oracle-java8-installer shared/accepted-oracle-license-v1-1 select true | sudo /usr/bin/debconf-set-selections
        apt-add-repository ppa:webupd8team/java
        apt-get update
        apt-get install -y oracle-java8-installer
        apt-get install -y oracle-java8-set-default
        apt-get install -y junit4 maven git

        # from the Dart install instructions: installing Dart in 3 Steps
        # 1. Setting up for the stable channel
        # Enable HTTPS for apt.
        apt-get update
        apt-get install apt-transport-https
        # Get the Google Linux package signing key.
        sh -c 'curl https://dl-ssl.google.com/linux/linux_signing_key.pub | apt-key add -'
        # Set up the location of the stable repository.
        sh -c 'curl https://storage.googleapis.com/download.dartlang.org/linux/debian/dart_stable.list > /etc/apt/sources.list.d/dart_stable.list'
        apt-get update
        # 2. Setting up for the dev channel
        sh -c 'curl https://storage.googleapis.com/download.dartlang.org/linux/debian/dart_unstable.list > /etc/apt/sources.list.d/dart_unstable.list'
        # 3. Installing the SDK
        apt-get install dart/stable

        sudo -u vagrant -i $0
        ;;
    *)
	echo "export PATH=/usr/lib/dart/bin:$PATH" > ~/.bash_profile

        ;;
esac
